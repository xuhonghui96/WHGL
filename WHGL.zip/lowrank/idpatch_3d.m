function y=idpatch_3d(f,x1,x2,x3,px,py,pz)

n=length(x1)*length(x2)*length(x3);
pad_f=padarray(f,[px,py,pz],'symmetric','post');

[nx,ny,nz]=size(pad_f);

k=px*py*pz;
y=false(n,k);

for j1=1:px
    for j2=1:py
        for j3=1:pz
            y(:,(j3-1)*px*py+(j2-1)*px+j1)=reshape(pad_f(j1+x1-1,j2+x2-1,j3+x3-1),n,[]);
        end
    end
end

